# Implementation Plan — AI Webcam Proctoring

This is the plan the feature was built to. Read it top-to-bottom to understand how the pieces were layered; each phase is independently shippable and matches the code in [code/](code/) and the file inventory in [04-FILES-TO-SHIP.md](04-FILES-TO-SHIP.md).

## Design goals (decided up front)

1. **Scale for free.** The exam engine must handle 200–300 concurrent candidates. Server-side video analysis (GPU inference or frame streaming) was ruled out — instead each candidate's own browser runs the models. The API only ever receives tiny events, small JPEG thumbnails, and S3 keys.
2. **Never break the exam.** Every proctoring path — model load, camera, snapshot, clip record, upload — is best-effort. A failure is logged as evidence-of-failure, but can never block, slow, or crash the test.
3. **Consent before camera.** DPDP/GDPR: `getUserMedia` is hard-gated behind an explicit consent dialog; consent is timestamped server-side and shown to reviewers.
4. **Candidate can't game the pipeline.** Owner-scoped endpoints, server-generated S3 keys, whitelisted labels, capped JSON lists, rate limits, S3 `head_object` verification before a clip is logged.
5. **Work inside the prod CSP.** Production CSP is `connect-src 'self'` — nothing may load from a CDN. Models + WASM are self-hosted under `/models`.

## Phase 0 — Prerequisites

- S3 bucket configured (`AWS_S3_BUCKET`, prod uses `ethara-hrms-doc`) with browser CORS: `POST` (direct clip upload) and `GET` (presigned playback/snapshot viewing) from the app origin.
- CSP updated so `img-src` / `media-src` / `connect-src` allow the S3 endpoint (for viewing evidence) while models stay self-hosted.
- Download MediaPipe assets into `ethara-hrms/public/models/`:
  - `face_landmarker.task` (3.6 MB), `efficientdet_lite0.tflite` (4.4 MB), `mediapipe-wasm/` runtime (33 MB).

## Phase 1 — Data model & per-test settings (backend)

- **One migration, one column:** `ap_attempts.proctoring` (nullable JSON) — [code/backend/f3a7c9e1d5b8_ap_attempt_proctoring.py](code/backend/f3a7c9e1d5b8_ap_attempt_proctoring.py). No new tables; all proctoring state for an attempt lives in this document (counts, events, snapshots, videos, consent, mediaErrors), each list capped so a hostile client can't grow it unbounded.
- **Config normalizer** `proctoring_config()` reads `assessment.settings.proctoring` and applies defaults: `requireFullscreen/blockTabSwitch/blockCopyPaste` off, `maxWarnings` 0, **`requireWebcam` defaults `True`** — every test is webcam-proctored unless an admin explicitly writes `requireWebcam: false`.
- Event-type → counter-key map (`_PROCTOR_COUNT_KEY`) covers both the classic anti-cheat events (`tab_switch`, `fullscreen_exit`, `copy`, `blur`) and the five AI signals (`look_away`, `multiple_faces`, `no_face`, `phone`, `talking`).

## Phase 2 — Browser detection engine (frontend, framework-agnostic)

File: [code/frontend/webcam-detector.ts](code/frontend/webcam-detector.ts) — a plain TypeScript class, no React.

- Load MediaPipe Tasks Vision via `FilesetResolver.forVisionTasks("/models/mediapipe-wasm")`.
- **FaceLandmarker** (`runningMode: "VIDEO"`, `numFaces: 3`, transformation matrices + blendshapes on) analysed every **300 ms**:
  - face count → `no_face` / `multiple_faces`
  - head yaw/pitch derived from the 4×4 facial transformation matrix → `look_away` when |yaw| > 28° or |pitch| > 22°
  - `jawOpen` blendshape sampled into a 10-slot rolling window; ≥ 3 open↔closed transitions → `talking` (distinguishes speech from a yawn, which opens once and stays open)
- **ObjectDetector** (EfficientDet-Lite0) analysed every **1500 ms**; any COCO detection matching `/cell phone|mobile phone|phone/i` with score ≥ 0.45 → `phone`.
- **Debounce + cooldown:** a signal must persist **3 consecutive analyses** to fire, and re-fires at most **once per 12 s** — kills one-frame blips and event spam.
- Emits `onSignal(signal)` (persisted) and `onStatus({faces, lookingAway, phone})` (live UI indicator only).

## Phase 3 — Evidence capture (frontend)

- **Snapshots** (in [webcam-proctor.tsx](code/frontend/webcam-proctor.tsx)): draw the `<video>` frame to a hidden canvas downscaled to **320 px wide**, encode JPEG q0.6, POST as multipart to the API. Taken at start (+1.5 s), every **25 s** ("periodic"), and on every signal (throttled to ≥ 12 s apart, so a burst of flags doesn't flood).
- **Violation clips** ([clip-recorder.ts](code/frontend/clip-recorder.ts)): on each signal, record **one fresh ~7 s MediaRecorder session** (720p video ~1.5 Mbps + Opus audio 96 kbps, webm ≈ 1.3 MB) and upload it **directly to S3** via presigned POST, then commit the key to the API. One continuous session per clip — an earlier ring-buffer design spliced webm headers and produced corrupt clips, so it was replaced with record-on-demand. If a flag fires while a clip is already recording, it's covered by the in-flight clip (no second recorder).
- **Media-error beacon:** every failing step (`snapshot-error`, `presign-error`, `s3-post-failed`, `clip-empty`, …) is reported to a diagnostics endpoint, deduped client-side to once per step per 30 s — a missing clip is now diagnosable instead of indistinguishable from a clean attempt.

## Phase 4 — Backend endpoints (FastAPI)

All six are candidate-side, **owner-scoped** (404 if the attempt isn't the caller's) and **IN_PROGRESS-gated** (silent no-op after submit). Full code: [code/backend/proctoring-backend-excerpts.md](code/backend/proctoring-backend-excerpts.md).

| Endpoint | Purpose | Hardening |
|---|---|---|
| `POST …/proctoring` | record one event, return updated counts | event type must be in the known map |
| `POST …/proctoring/consent` | timestamp consent (idempotent — first timestamp wins) | rate-limited |
| `POST …/proctoring/snapshot` | store JPEG/PNG/WebP thumbnail ≤ 2 MB | content-type whitelist; pushed to S3 when a bucket is configured |
| `POST …/proctoring/video/presign` | presigned POST for one clip | **server generates the key** (random token under the attempt's prefix), Content-Type pinned `video/webm`, size 1 B–10 MB, expires 120 s, 6/min |
| `POST …/proctoring/video/commit` | log an uploaded clip | key must be under the attempt's own prefix; `head_object` verifies it actually landed in S3 (no phantom keys), 12/min |
| `POST …/proctoring/media-error` | diagnostics beacon | step whitelisted, message truncated to 200 chars, list capped at 50, 30/min |

## Phase 5 — Exam-player integration & consent gate

- [attempt-player.tsx](code/frontend/attempt-player.tsx) mounts `<WebcamProctor>` when `proctoring.requireWebcam` and the attempt is active; its `onSignal` records the event via the same API used by tab-switch/fullscreen violations. It also owns the non-AI anti-cheat: `visibilitychange` → `tab_switch`, `fullscreenchange` → `fullscreen_exit` (with re-prompt), copy/cut/paste/contextmenu + Ctrl-key blocking, warning counter with auto-submit at `maxWarnings`, and the pre-test instructions banner.
- [webcam-proctor.tsx](code/frontend/webcam-proctor.tsx) renders the blocking consent dialog first; on accept it records consent, then requests **720p video + echo-cancelled/noise-suppressed audio**, initialises the detector, attaches the clip recorder, and shows a mirrored self-view (bottom-right) with a live status pill (No face / Multiple faces / Phone seen / Look at screen / REC) so the candidate always knows they're monitored. Camera-denied and camera-error states show actionable banners.

## Phase 6 — Reviewer integrity report

- `serialize_proctoring_report()` (service) returns counts + event timeline + snapshots + clips + consent + mediaErrors, swapping every private S3 reference for a **1-hour presigned GET**.
- [proctoring-report.tsx](code/frontend/proctoring-report.tsx) renders it on the results and grading pages: per-signal count chips, human-labelled timeline, snapshot gallery with lightbox, playable `<video>` clips, and the media-error list explaining any gaps.

## Phase 7 — Rollout & ops

- **Default ON** for all tests, new and existing (backend default `requireWebcam: True`); the assessment editor exposes a "Require webcam — AI proctoring" checkbox that writes an explicit `false` to opt a test out. Proctoring config is frozen into the attempt snapshot at start, so a settings change applies to future starts only.
- Deploy steps: `alembic upgrade head` → API restart (systemd `ethara-hrms-api`, gunicorn :3001) → frontend `npm run build` + restart (systemd `ethara-hrms-frontend`, :3000). Verify `/models/*` are served (they're static `public/` assets) and S3 CORS allows browser POST/GET.
- **Current status: all phases deployed to production** (13 Jul 2026), including the media-capture fixes (multipart snapshot header, record-forward clips, audio capture, per-flag clips without cooldown).

## Known limitations (agreed trade-offs)

- A browser **cannot** block Alt+Tab / OS-level app switching — it can only detect and record it. True lockdown needs Safe Exam Browser or an Electron shell (evaluated, not built).
- Detection quality depends on the candidate's lighting/camera; thresholds (28° yaw, 22° pitch, 0.45 phone score) were tuned to bias against false positives, and the debounce/cooldown layer absorbs the rest.
- Evidence lists are intentionally capped per attempt (200 events / 100 snapshots / 30 clips / 50 media-errors) — oldest entries drop first.
- Very old browsers without MediaRecorder webm support silently skip clips (snapshots still work); `ClipRecorder.isSupported()` guards this.
