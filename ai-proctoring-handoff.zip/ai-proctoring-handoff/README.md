# AI Webcam Proctoring — Team Handoff Package

**Feature:** AI-based webcam proctoring for the Assessment Platform (online test engine) in the Ethara HRMS.
**Status:** Live in production (deployed 13 Jul 2026, default **ON** for all tests).
**Prepared:** 14 Jul 2026. This folder is documentation + verbatim code copies only — nothing in the codebase was modified.

## What the feature does

While a candidate (or employee) takes a test, their own browser runs two computer-vision models on the webcam feed and flags integrity violations in real time:

| Signal | Detected by |
|---|---|
| `no_face` — candidate left the frame | Face landmarker (face count = 0) |
| `multiple_faces` — someone else in frame | Face landmarker (face count > 1) |
| `look_away` — head turned away from screen | Face landmarker (head yaw/pitch from the facial transformation matrix) |
| `phone` — mobile phone visible | Object detector (EfficientDet-Lite0, COCO classes) |
| `talking` — sustained lip movement | Face landmarker (`jawOpen` blendshape oscillation) |

On every flag the browser uploads **evidence**: a downscaled JPEG snapshot (via the API) and a fresh ~7-second **audio + video webm clip** (direct to S3 via presigned POST). Periodic snapshots are also taken every 25 s. Reviewers see everything — per-signal counts, an event timeline, snapshot gallery, and playable clips — on the attempt's integrity report.

**The key architectural decision:** all AI inference runs **client-side** in the candidate's browser (MediaPipe Tasks Vision, WASM). 300 concurrent candidates = 300 browsers doing the work. Zero server GPU, zero per-candidate inference cost, and video frames never leave the machine except as explicit evidence snapshots/clips.

It layers on top of the existing non-AI anti-cheat in the same module: tab-switch detection, fullscreen enforcement, copy/paste blocking, and auto-submit after N warnings.

## Folder contents

| File | What it covers |
|---|---|
| [01-IMPLEMENTATION-PLAN.md](01-IMPLEMENTATION-PLAN.md) | Phase-by-phase plan of how the feature is built — use it to understand, review, or reproduce the implementation |
| [02-HOW-IT-WORKS.md](02-HOW-IT-WORKS.md) | Runtime architecture: end-to-end data flow, detection thresholds, API endpoints, data model, storage, security & privacy |
| [03-LIBRARIES-AND-MODELS.md](03-LIBRARIES-AND-MODELS.md) | Every library, ML model, and browser API used, with versions, sizes, and why each was chosen |
| [04-FILES-TO-SHIP.md](04-FILES-TO-SHIP.md) | Complete inventory of source files that make up the feature (with line ranges for shared files) — the "what to ship" list |
| [code/frontend/](code/frontend/) | Verbatim copies of the 5 frontend files + excerpts from shared files (`api.ts`, editor page) |
| [code/backend/](code/backend/) | The DB migration (verbatim) + excerpts of the service functions and the 6 API endpoints |

## 60-second summary for the team

1. **Browser-side engine** ([webcam-detector.ts](code/frontend/webcam-detector.ts)): MediaPipe `FaceLandmarker` + `ObjectDetector` run on the webcam `<video>` element a few times per second. Signals are debounced (must persist 3 consecutive analyses) and cooled down (same signal ≤ once / 12 s) so a glance or a one-frame misdetection doesn't spam the backend.
2. **Consent first** ([webcam-proctor.tsx](code/frontend/webcam-proctor.tsx)): a blocking DPDP/GDPR consent dialog gates `getUserMedia` — the camera cannot start until the candidate explicitly agrees; consent is timestamped server-side.
3. **Evidence** ([clip-recorder.ts](code/frontend/clip-recorder.ts)): each violation triggers a snapshot + one clean ~7 s MediaRecorder webm clip (VP8/VP9 + Opus audio, 720p) uploaded **directly to S3** with a server-issued presigned POST — clip bytes never pass through the API.
4. **Backend** (FastAPI): 6 small owner-scoped endpoints record events/consent/snapshots/clips/upload-failures into one JSON column (`ap_attempts.proctoring`) with capped lists — no new tables.
5. **Reviewer report** ([proctoring-report.tsx](code/frontend/proctoring-report.tsx)): counts, timeline, snapshots, and clips (served via 1-hour presigned GETs) on the results/grading pages.
6. **Rollout**: webcam proctoring defaults ON for every test; admins can switch it off per test in the assessment editor ("Require webcam" toggle).
