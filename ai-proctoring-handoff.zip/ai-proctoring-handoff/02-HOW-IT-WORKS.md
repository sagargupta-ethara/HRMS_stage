# How the Implementation Works — Runtime Architecture

## Big picture

```
CANDIDATE'S BROWSER (does all the AI work)                 SERVER SIDE
┌────────────────────────────────────────────┐
│ attempt-player.tsx                         │
│  • tab-switch / fullscreen / copy-paste    │──events──▶ FastAPI
│  • warning counter → auto-submit           │            POST …/proctoring
│  • mounts WebcamProctor when requireWebcam │                 │
│                                            │                 ▼
│ webcam-proctor.tsx                         │        ap_attempts.proctoring
│  1. consent dialog  ──consent──────────────┼──────▶  (single JSON column:
│  2. getUserMedia (720p + mic)              │          counts, events[≤200],
│  3. WebcamDetector (MediaPipe WASM)        │          snapshots[≤100],
│     FaceLandmarker  every 300ms            │          videos[≤30], consent,
│     ObjectDetector  every 1500ms           │          mediaErrors[≤50])
│     └─ onSignal ──────────────────────────┼──event──▶
│  4. canvas JPEG snapshot (320px) ──────────┼──file───▶ StorageService → S3
│  5. ClipRecorder ~7s webm (A/V)            │
│     presign ◀──────────────────────────────┼─────────  presigned POST (120s,
│     clip bytes ────────────────────────────┼──▶ S3     10MB cap, webm only)
│     commit key ────────────────────────────┼─────────▶ head_object verify
└────────────────────────────────────────────┘
                                                REVIEWER: proctoring-report.tsx
                                                counts + timeline + snapshots +
                                                clips via 1h presigned GETs
```

## End-to-end flow of one attempt

1. **Start.** The attempt payload includes the frozen `proctoring` config (from `assessment.settings.proctoring`, normalized with `requireWebcam` defaulting **true**) and current violation counts. Config is snapshotted at attempt start — mid-exam settings changes don't apply.
2. **Consent.** `WebcamProctor` renders a blocking modal over the exam. Camera code is unreachable until the candidate checks the box and clicks consent; the click fires `POST …/proctoring/consent` (idempotent — the first timestamp is preserved) and only then does `getUserMedia` run, requesting 1280×720 video + echo-cancelled/noise-suppressed audio.
3. **Detection loop.** `WebcamDetector` runs a `requestAnimationFrame` loop over the live `<video>`:
   - every **300 ms** → `FaceLandmarker.detectForVideo()`: face count, head pose from the facial transformation matrix (yaw/pitch via `atan2` on the rotation sub-matrix), `jawOpen` blendshape.
   - every **1500 ms** → `ObjectDetector.detectForVideo()`: phone classes at score ≥ 0.45.
   - A raw condition only becomes a **signal** after 3 consecutive positive analyses (SUSTAIN), and the same signal re-fires at most every 12 s (COOLDOWN).
4. **On each signal**, three things happen in parallel, all best-effort:
   - `POST …/proctoring {type}` increments the counter and appends `{type, at}` to the event timeline (capped 200).
   - a **snapshot** (canvas → 320 px JPEG q0.6) is uploaded multipart to `…/proctoring/snapshot` with the signal as `reason` (throttled ≥ 12 s between snapshots; periodic ones fire every 25 s regardless).
   - a **clip**: `ClipRecorder.captureClip()` records one fresh 7 s MediaRecorder segment (VP8/VP9 + Opus, ~1.3 MB), then `presign → POST to S3 → commit`. The S3 POST goes straight from the browser to the bucket; the API only issues the policy and verifies the landed object with `head_object` before logging the key.
5. **Any failure** in that pipeline (camera not ready, empty blob, presign 4xx, S3 CORS reject, commit error) is beaconed to `…/proctoring/media-error` — whitelisted step label, truncated message, capped list — so the reviewer report can explain *why* evidence is missing.
6. **Classic anti-cheat** runs alongside in `attempt-player.tsx`: `visibilitychange` → `tab_switch`, `fullscreenchange` → `fullscreen_exit` (1.5 s dedup + re-prompt), copy/cut/paste/contextmenu and Ctrl+C/V/X/P/S/U suppression → `copy`. `tab_switch` + `fullscreen_exit` feed the warning counter; hitting `maxWarnings` **auto-submits** the attempt with reason "violations".
7. **Submit.** All proctoring endpoints check `status is IN_PROGRESS` — after submission every recorder call is a silent no-op, so nothing can be appended to a finished attempt.
8. **Review.** The staff results/grading pages call the attempt-report endpoint; `serialize_proctoring_report()` returns counts/timeline/snapshots/videos/consent/mediaErrors with every S3 reference swapped for a **1-hour presigned GET**. `proctoring-report.tsx` renders count chips, a human-labelled timeline, a snapshot lightbox gallery, and playable clips.

## Detection thresholds (tuning knobs, all in `webcam-detector.ts`)

| Constant | Value | Meaning |
|---|---|---|
| `FACE_INTERVAL_MS` / `OBJECT_INTERVAL_MS` | 300 / 1500 | analysis cadence (light on low-end laptops) |
| `SUSTAIN` | 3 | consecutive positive analyses before a signal fires |
| `COOLDOWN_MS` | 12 000 | min gap between re-fires of the same signal |
| `YAW_LIMIT` / `PITCH_LIMIT` | 28° / 22° | head-pose bounds for `look_away` |
| `PHONE_SCORE` | 0.45 | ObjectDetector confidence floor |
| `MOUTH_OPEN_THRESHOLD` | 0.15 | `jawOpen` blendshape open/closed boundary |
| `MOUTH_WINDOW` / `MOUTH_MIN_TRANSITIONS` | 10 / 3 | rolling samples & open↔closed flips to call `talking` (a yawn = 1 transition, speech = many) |

Capture knobs: snapshots 320 px JPEG q0.6, periodic 25 s, on-signal throttle 12 s; clips 7 s @ 720p, 1.5 Mbps video + 96 kbps Opus.

## API surface (all under `/api/v1/assessment-platform`)

| Method & path | Caller | Notes |
|---|---|---|
| `POST /me/attempts/{id}/proctoring` | candidate | body `{type}`; returns updated counts |
| `POST /me/attempts/{id}/proctoring/consent` | candidate | idempotent, stores `{at, version}` |
| `POST /me/attempts/{id}/proctoring/snapshot` | candidate | multipart `file` + `reason`; ≤ 2 MB, jpeg/png/webp; stored to S3 when bucket configured |
| `POST /me/attempts/{id}/proctoring/video/presign` | candidate | 6/min; server-generated random key `assessment-platform/proctoring-video/{attempt}/{token}.webm`; policy pins `video/webm`, 1 B–10 MB, 120 s expiry |
| `POST /me/attempts/{id}/proctoring/video/commit` | candidate | 12/min; key must match the attempt's own prefix; `head_object` verifies existence |
| `POST /me/attempts/{id}/proctoring/media-error` | candidate | 30/min; whitelisted `step`, bounded payload |

Every endpoint loads the attempt via `_load_attempt_lite` (owner-scoped → 404 for anyone else's attempt; defers the heavy `snapshot`/`proctoring` JSON blobs for the hot list paths) and no-ops unless the attempt is `IN_PROGRESS`.

## Data model

No new tables. `ap_attempts.proctoring` (JSON, nullable — migration `f3a7c9e1d5b8`) holds:

```jsonc
{
  "counts":   { "lookAways": 4, "multipleFaces": 0, "noFace": 1, "phoneDetections": 2,
                "talkingEvents": 0, "tabSwitches": 3, "fullscreenExits": 1,
                "copyAttempts": 0, "blurEvents": 2 },
  "events":    [ { "type": "look_away", "at": "2026-07-13T09:14:02Z" }, … ],   // last 200
  "snapshots": [ { "url": "…", "reason": "phone", "at": "…" }, … ],            // last 100
  "videos":    [ { "url": "<s3-key>", "reason": "phone", "at": "…" }, … ],     // last 30
  "consent":   { "at": "2026-07-13T09:10:11Z", "version": "v1" },
  "mediaErrors": [ { "step": "s3-post-failed", "status": 403, "message": "…", "at": "…" } ] // last 50
}
```

Per-test config lives in `ap_assessments.settings.proctoring` (`requireWebcam`, `requireFullscreen`, `blockTabSwitch`, `blockCopyPaste`, `maxWarnings`).

## Storage layout (S3, private bucket)

- Snapshots: `assessment-platform/proctoring/{attempt_id}/…` (uploaded via API → `StorageService.save_upload`, forced to S3 when a bucket is configured even if `STORAGE_BACKEND` is local — offloads disk I/O at scale)
- Clips: `assessment-platform/proctoring-video/{attempt_id}/{random-32-hex}.webm` (browser → S3 direct)
- Serving: reviewers only — short-lived presigned GETs minted at report render time; nothing is public.

## Security & privacy properties

- **Consent-gated camera** (DPDP/GDPR), consent timestamp shown to reviewers; the self-view + REC pill keeps monitoring visible to the candidate at all times.
- **Owner scoping everywhere** — a candidate can only write proctoring data to their *own in-progress* attempt.
- **No client-chosen keys**: S3 object keys are server-generated; commit rejects keys outside the attempt's prefix and phantom keys that never landed.
- **Bounded writes**: whitelisted event types & error steps, truncated strings, capped lists, rate limits — a hostile client can't bloat or poison the attempt JSON.
- **Candidate-facing responses never include proctoring evidence** — the report is only serialized on staff endpoints.
- Video frames are processed in-memory in the browser; the only persisted media are the explicit evidence snapshots/clips.

## Failure modes & their handling

| Failure | Behaviour |
|---|---|
| Camera denied / hardware error | Red banner tells the candidate to fix & reload; `onReady(false)` — exam continues per current policy |
| Model/WASM load failure | `error` phase, same banner; no crash |
| Browser lacks MediaRecorder/webm | Clips silently skipped (`ClipRecorder.isSupported()`); snapshots still flow |
| Any upload failure | media-error beacon (deduped 30 s/step) → visible in reviewer report |
| Attempt already submitted | All endpoints no-op (`stored/logged: false`) |
| S3 unconfigured | presign returns `{presign: null}`; snapshots fall back to local `/uploads` |
