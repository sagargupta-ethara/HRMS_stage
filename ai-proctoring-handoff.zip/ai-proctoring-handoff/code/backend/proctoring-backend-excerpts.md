# Backend proctoring code — verbatim excerpts

The backend proctoring logic lives inside two large shared files of the Assessment Platform module. The full files should be shipped as-is; these excerpts isolate the proctoring sections so a reviewer does not have to hunt through ~2,000-line files.

## 1. Service layer — `app/services/assessment_platform.py` (lines 51–219)

Per-test config + defaults, event counters, evidence recorders, consent, media-error log, and the reviewer report serializer.

```python
# ── proctoring / anti-cheat ──
_PROCTORING_DEFAULTS: dict[str, Any] = {
    "requireFullscreen": False,
    "blockTabSwitch": False,
    "blockCopyPaste": False,
    "maxWarnings": 0,
    # Webcam AI proctoring: taker grants camera; the browser runs MediaPipe/TF.js locally and
    # reports flags (look-away, extra faces, absence, phone, talking) + periodic snapshots.
    # DEFAULT ON for every test (new + existing) — a test whose settings don't explicitly set
    # requireWebcam is webcam-proctored. An admin can still turn it OFF per test in the editor
    # (which then writes requireWebcam:false explicitly). Turning it on requires camera consent to start.
    "requireWebcam": True,
}
_PROCTOR_COUNT_KEY = {
    "tab_switch": "tabSwitches",
    "fullscreen_exit": "fullscreenExits",
    "copy": "copyAttempts",
    "blur": "blurEvents",
    # webcam AI signals
    "look_away": "lookAways",
    "multiple_faces": "multipleFaces",
    "no_face": "noFace",
    "phone": "phoneDetections",
    "talking": "talkingEvents",
}


def proctoring_config(settings: dict[str, Any] | None) -> dict[str, Any]:
    """Normalize the per-assessment anti-cheat settings (stored in assessment.settings.proctoring)."""
    raw = (settings or {}).get("proctoring") or {}
    cfg = {
        "requireFullscreen": bool(raw.get("requireFullscreen", _PROCTORING_DEFAULTS["requireFullscreen"])),
        "blockTabSwitch": bool(raw.get("blockTabSwitch", _PROCTORING_DEFAULTS["blockTabSwitch"])),
        "blockCopyPaste": bool(raw.get("blockCopyPaste", _PROCTORING_DEFAULTS["blockCopyPaste"])),
        "maxWarnings": int(raw.get("maxWarnings", _PROCTORING_DEFAULTS["maxWarnings"]) or 0),
        "requireWebcam": bool(raw.get("requireWebcam", _PROCTORING_DEFAULTS["requireWebcam"])),
    }
    cfg["enabled"] = (
        cfg["requireFullscreen"] or cfg["blockTabSwitch"] or cfg["blockCopyPaste"] or cfg["requireWebcam"]
    )
    return cfg


def proctoring_counts(attempt: ApAttempt) -> dict[str, int]:
    counts = (attempt.proctoring or {}).get("counts") or {}
    return {key: int(counts.get(key, 0)) for key in _PROCTOR_COUNT_KEY.values()}


def serialize_proctoring_report(attempt: ApAttempt) -> dict[str, Any]:
    """Full anti-cheat report for the reviewer's integrity view: per-signal counts + the
    event timeline (type + time) + webcam snapshot references (url + reason + time).

    S3-stored snapshots are private, so each URL is swapped for a short-lived presigned link
    the reviewer's browser can load. Local (/uploads) snapshots pass through unchanged."""
    from app.services.integrations import StorageService  # lazy: avoid import cycle

    data = attempt.proctoring or {}
    storage = StorageService()
    snapshots = []
    for snap in data.get("snapshots") or []:
        raw = snap.get("url") or ""
        snapshots.append({**snap, "url": storage.presigned_download_url(raw, expires_in=3600) or raw})
    # Violation video clips store only the private S3 key; swap each for a short-lived presigned GET
    # the reviewer's browser can play (same treatment as snapshots). presigned_download_url expects a
    # full/s3:// URL, so a bare key is wrapped as s3://<bucket>/<key> first.
    bucket = storage.settings.aws_s3_bucket
    videos = []
    for vid in data.get("videos") or []:
        raw = vid.get("url") or ""
        lookup = raw if raw.startswith(("http://", "https://", "s3://")) else (f"s3://{bucket}/{raw}" if bucket else raw)
        videos.append({**vid, "url": storage.presigned_download_url(lookup, expires_in=3600) or raw})
    return {
        "counts": proctoring_counts(attempt),
        "events": list(data.get("events") or []),
        "snapshots": snapshots,
        "videos": videos,
        # Whether/when the candidate consented to webcam recording (DPDP/GDPR); null if never given.
        "consent": data.get("consent") or None,
        # Client-reported media-upload failures (which step failed + why) so a reviewer can see WHY a
        # clip/snapshot is missing instead of a silent gap. Empty when every upload succeeded.
        "mediaErrors": list(data.get("mediaErrors") or []),
    }


def record_proctoring_event(attempt: ApAttempt, event_type: str) -> dict[str, int]:
    """Increment the counter for a violation type + append to a capped event log."""
    data = dict(attempt.proctoring or {})
    counts = dict(data.get("counts") or {})
    key = _PROCTOR_COUNT_KEY.get(event_type)
    if key:
        counts[key] = int(counts.get(key, 0)) + 1
    events = [*(data.get("events") or []), {"type": event_type, "at": datetime.now(UTC).isoformat()}]
    data["counts"] = counts
    data["events"] = events[-200:]
    attempt.proctoring = data
    return {k: int(counts.get(k, 0)) for k in _PROCTOR_COUNT_KEY.values()}


def record_proctoring_snapshot(attempt: ApAttempt, url: str, reason: str) -> None:
    """Append a webcam snapshot reference (capped at 100) to the proctoring log for the
    reviewer. Stores only the stored-file URL + reason + timestamp, never the image bytes."""
    data = dict(attempt.proctoring or {})
    snaps = [
        *(data.get("snapshots") or []),
        {"url": url, "reason": reason, "at": datetime.now(UTC).isoformat()},
    ]
    data["snapshots"] = snaps[-100:]
    attempt.proctoring = data


def record_proctoring_video(attempt: ApAttempt, key: str, reason: str) -> None:
    """Append a proctoring video-clip reference (S3 key, capped at 30) to the proctoring log for the
    reviewer. Stores only the object key + reason + timestamp — the clip bytes live in the private
    bucket and are served via a short-lived presigned GET (see serialize_proctoring_report)."""
    data = dict(attempt.proctoring or {})
    videos = [
        *(data.get("videos") or []),
        {"url": key, "reason": str(reason)[:40], "at": datetime.now(UTC).isoformat()},
    ]
    data["videos"] = videos[-30:]
    attempt.proctoring = data


def record_proctoring_consent(attempt: ApAttempt) -> dict[str, Any]:
    """Record the candidate's explicit webcam-proctoring consent on the attempt (DPDP/GDPR).

    Idempotent: consent is captured ONCE per attempt and the FIRST timestamp is preserved, so the
    reviewer sees when the candidate actually agreed (not the latest retry). Stores only a timestamp
    + policy version — no extra PII. Returns the recorded consent record."""
    data = dict(attempt.proctoring or {})
    existing = data.get("consent")
    if not (isinstance(existing, dict) and existing.get("at")):
        data["consent"] = {"at": datetime.now(UTC).isoformat(), "version": "v1"}
        attempt.proctoring = data
    return data["consent"]


# Whitelist of client media-upload failure steps — bounds the candidate-supplied `step` label so a
# hostile client can't stuff arbitrary strings into the attempt JSON. Anything else becomes "other".
_PROCTOR_MEDIA_ERROR_STEPS = frozenset({
    "recorder-unsupported", "clip-empty", "presign-null", "presign-error",
    "s3-post-error", "s3-post-failed", "commit-error", "capture-error",
    "snapshot-not-ready", "snapshot-empty", "snapshot-not-stored", "snapshot-error",
})


def record_proctoring_media_error(
    attempt: ApAttempt, step: str, status_code: Any, message: str
) -> None:
    """Log a client-side proctoring MEDIA upload failure (which step failed + why) on the attempt so
    a reviewer can see WHY a clip/snapshot is missing instead of a silent gap. Tightly bounded: the
    step is whitelisted, the message truncated, the status coerced to int|None, and the list capped
    at the last 50 — a candidate can neither grow the JSON without limit nor inject arbitrary data."""
    try:
        code: int | None = int(status_code) if status_code is not None else None
    except (TypeError, ValueError):
        code = None
    data = dict(attempt.proctoring or {})
    errs = [
        *(data.get("mediaErrors") or []),
        {
            "step": step if step in _PROCTOR_MEDIA_ERROR_STEPS else "other",
            "status": code,
            "message": str(message or "")[:200],
            "at": datetime.now(UTC).isoformat(),
        },
    ]
    data["mediaErrors"] = errs[-50:]
    attempt.proctoring = data
```

## 2. API endpoints — `app/api/routes/assessment_platform.py` (lines 1960–2139)

Six candidate-side endpoints (all owner-scoped and IN_PROGRESS-gated): record event, consent, snapshot upload, S3 presign, S3 commit, media-error beacon.

```python
_MAX_PROCTOR_SNAPSHOT_MB = 2


@router.post("/me/attempts/{attempt_id}/proctoring")
def record_proctoring(
    attempt_id: str,
    payload: ProctoringEventRequest,
    db: DbDep,
    current_user: Annotated[User, Depends(get_current_user)],
) -> dict[str, Any]:
    """Record an anti-cheat event (tab switch / fullscreen exit / copy / blur, or a webcam
    AI flag: look_away / multiple_faces / no_face / phone / talking). Webcam flags fire every
    few seconds per candidate, so use the lite load (no snapshot/answers) to keep it cheap."""
    attempt = _load_attempt_lite(db, attempt_id, current_user)
    if attempt.status is not ApAttemptStatus.IN_PROGRESS:
        return {"counts": svc.proctoring_counts(attempt)}
    if payload.type not in _PROCTOR_EVENT_TYPES:
        raise HTTPException(status_code=400, detail="Unknown proctoring event")
    counts = svc.record_proctoring_event(attempt, payload.type)
    db.commit()
    return {"counts": counts}


@router.post("/me/attempts/{attempt_id}/proctoring/consent")
@limiter.limit("12/minute")
def record_proctoring_consent(
    request: Request,
    attempt_id: str,
    db: DbDep,
    current_user: Annotated[User, Depends(get_current_user)],
) -> dict[str, Any]:
    """Record the candidate's explicit, informed consent to webcam proctoring + recording for this
    attempt (DPDP/GDPR). Owner-scoped via _load_attempt_lite (404 if not the caller's) + IN_PROGRESS
    -gated + idempotent: a repeat call preserves the first consent timestamp. Stores only a timestamp
    + policy version on the attempt — no extra PII. The browser calls this AFTER the candidate
    actively consents and BEFORE the camera starts."""
    attempt = _load_attempt_lite(db, attempt_id, current_user)
    if attempt.status is not ApAttemptStatus.IN_PROGRESS:
        return {"consent": (attempt.proctoring or {}).get("consent")}
    consent = svc.record_proctoring_consent(attempt)
    db.commit()
    return {"consent": consent}


@router.post("/me/attempts/{attempt_id}/proctoring/snapshot")
def record_proctoring_snapshot(
    attempt_id: str,
    db: DbDep,
    current_user: Annotated[User, Depends(get_current_user)],
    file: Annotated[UploadFile, File()],
    reason: Annotated[str, Form()] = "periodic",
) -> dict[str, Any]:
    """Store one webcam snapshot (small JPEG/PNG thumbnail) as reviewer evidence and log a
    reference on the attempt. Silently no-ops once the attempt is submitted."""
    attempt = _load_attempt_lite(db, attempt_id, current_user)
    if attempt.status is not ApAttemptStatus.IN_PROGRESS:
        return {"stored": False}
    # Push proctoring snapshots to S3 when a bucket is configured (offloads local-disk I/O +
    # growth at 200-300 concurrent), regardless of the global STORAGE_BACKEND. They serve to
    # reviewers via short-lived presigned URLs (see serialize_proctoring_report).
    snapshot_backend = "s3" if get_settings().aws_s3_bucket else None
    file_url, _file_path = StorageService().save_upload(
        file,
        folder=f"assessment-platform/proctoring/{attempt.id}",
        allowed_content_types={"image/jpeg", "image/png", "image/webp"},
        max_size_bytes=_MAX_PROCTOR_SNAPSHOT_MB * 1024 * 1024,
        backend=snapshot_backend,
    )
    svc.record_proctoring_snapshot(attempt, file_url, reason[:40])
    db.commit()
    return {"stored": True, "url": file_url}


# On a violation the browser records a ~10s webcam clip and uploads it STRAIGHT to S3 with a
# short-lived presigned POST — the clip bytes never pass through the API (keeps the hot path cheap
# at 200-300 concurrent). S3 conditions cap the object at 10 MB and video/webm only.
_MAX_PROCTOR_VIDEO_BYTES = 10 * 1024 * 1024


def _proctor_s3_client() -> Any:
    settings = get_settings()
    return boto3.client(
        "s3",
        region_name=settings.aws_region,
        aws_access_key_id=settings.aws_access_key_id,
        aws_secret_access_key=settings.aws_secret_access_key,
    )


@router.post("/me/attempts/{attempt_id}/proctoring/video/presign")
@limiter.limit("6/minute")
def presign_proctoring_video(
    request: Request,
    attempt_id: str,
    db: DbDep,
    current_user: Annotated[User, Depends(get_current_user)],
) -> dict[str, Any]:
    """Hand the candidate's OWN browser a short-lived presigned POST to upload one ~10s webcam clip
    DIRECT to S3 when a proctoring violation fires. Owner-scoped (404 via _load_attempt_lite if the
    attempt isn't the caller's) + IN_PROGRESS-gated; returns {"presign": None} when there's nothing
    to sign for (finished attempt / no bucket configured). The object key is SERVER-generated with a
    random token, so the client can neither choose the key nor overwrite an existing object. The
    conditions cap the upload at 10 MB and pin Content-Type to video/webm."""
    attempt = _load_attempt_lite(db, attempt_id, current_user)
    settings = get_settings()
    if attempt.status is not ApAttemptStatus.IN_PROGRESS or not settings.aws_s3_bucket:
        return {"presign": None}
    key = f"assessment-platform/proctoring-video/{attempt.id}/{secrets.token_hex(16)}.webm"
    presigned = _proctor_s3_client().generate_presigned_post(
        Bucket=settings.aws_s3_bucket,
        Key=key,
        Fields={"Content-Type": "video/webm"},
        Conditions=[
            {"Content-Type": "video/webm"},
            ["content-length-range", 1, _MAX_PROCTOR_VIDEO_BYTES],
        ],
        ExpiresIn=120,
    )
    return {"url": presigned["url"], "fields": presigned["fields"], "key": key}


@router.post("/me/attempts/{attempt_id}/proctoring/video/commit")
@limiter.limit("12/minute")
def commit_proctoring_video(
    request: Request,
    attempt_id: str,
    db: DbDep,
    current_user: Annotated[User, Depends(get_current_user)],
    key: Annotated[str, Body()],
    reason: Annotated[str, Body()] = "violation",
) -> dict[str, Any]:
    """Confirm a proctoring clip the browser just uploaded DIRECT to S3 and log a reference on the
    attempt. Owner-scoped + IN_PROGRESS-gated. The key MUST live under this attempt's server-issued
    prefix — rejects any attempt to log an object outside the caller's own clip namespace (400)."""
    attempt = _load_attempt_lite(db, attempt_id, current_user)
    if attempt.status is not ApAttemptStatus.IN_PROGRESS:
        return {"stored": False}
    prefix = f"assessment-platform/proctoring-video/{attempt.id}/"
    if not (key or "").startswith(prefix) or len(key) > 200:
        raise HTTPException(status_code=400, detail="Invalid video key")
    # Only record a clip that actually landed in S3 under the caller's own prefix — this confirms
    # the browser's direct upload AND blocks logging a phantom key (which would render as a broken
    # <video> in the reviewer's integrity report). S3 is read-after-write consistent for new keys.
    bucket = get_settings().aws_s3_bucket
    if bucket:
        try:
            _proctor_s3_client().head_object(Bucket=bucket, Key=key)
        except Exception:
            return {"stored": False}
    svc.record_proctoring_video(attempt, key, reason)
    db.commit()
    return {"stored": True}


@router.post("/me/attempts/{attempt_id}/proctoring/media-error")
@limiter.limit("30/minute")
def record_proctoring_media_error(
    request: Request,
    attempt_id: str,
    db: DbDep,
    current_user: Annotated[User, Depends(get_current_user)],
    step: Annotated[str, Body()],
    message: Annotated[str, Body()] = "",
    status_code: Annotated[int | None, Body()] = None,
) -> dict[str, Any]:
    """Record a client-side proctoring MEDIA upload failure (which step failed + why) on the attempt.
    Proctoring uploads are best-effort and were previously swallowed silently, so a missing clip was
    indistinguishable from a clean attempt; this beacon makes the failing step visible to reviewers.
    Owner-scoped via _load_attempt_lite (404 if not the caller's) + IN_PROGRESS-gated + rate-limited,
    and the payload is tightly bounded server-side (whitelisted step, truncated message, capped log)
    so a candidate cannot abuse it to bloat or poison the attempt record."""
    attempt = _load_attempt_lite(db, attempt_id, current_user)
    if attempt.status is not ApAttemptStatus.IN_PROGRESS:
        return {"logged": False}
    svc.record_proctoring_media_error(attempt, step[:40], status_code, message)
    db.commit()
    return {"logged": True}


# ═══════════════════════════════ GRADING ══════════════════════════════════════
```

## 3. Request schema — `app/schemas/assessment_platform.py` (line 194)

```python
class ProctoringEventRequest(ORMModel):
    type: str = Field(max_length=100)
```

## 4. DB column — `app/db/models.py` (line 2211, on the `ap_attempts` table)

```python
    proctoring: Mapped[dict[str, Any] | None] = mapped_column(JSON)
```

## 5. Migration — `alembic/versions/f3a7c9e1d5b8_ap_attempt_proctoring.py`

Full copy in this folder: [f3a7c9e1d5b8_ap_attempt_proctoring.py](f3a7c9e1d5b8_ap_attempt_proctoring.py). Adds one nullable JSON column `proctoring` to `ap_attempts`.
