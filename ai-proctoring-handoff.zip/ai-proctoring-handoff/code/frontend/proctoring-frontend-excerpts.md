# Frontend proctoring code — excerpts from shared files

The four proctoring-specific frontend files are copied verbatim into this folder. Two shared files also carry proctoring code; the relevant sections are excerpted here.

## 1. API client methods — `src/lib/api.ts` (lines 5239–5280)

```typescript
  proctoringEvent: async (attemptId: string, type: ApProctoringEventType) => {
    const { data } = await api.post(`${AP}/me/attempts/${attemptId}/proctoring`, { type });
    return data as { counts: ApProctoringCounts };
  },
  proctoringSnapshot: async (attemptId: string, blob: Blob, reason: string) => {
    const form = new FormData();
    form.append("file", blob, "snapshot.jpg");
    form.append("reason", reason);
    // The axios instance defaults to Content-Type: application/json; without this override the
    // multipart body is sent as JSON and FastAPI rejects it with 422 (matches every other upload).
    const { data } = await api.post(`${AP}/me/attempts/${attemptId}/proctoring/snapshot`, form, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return data as { stored: boolean; url?: string };
  },
  proctoringVideoPresign: async (attemptId: string): Promise<ApProctoringVideoPresign> => {
    const { data } = await api.post(`${AP}/me/attempts/${attemptId}/proctoring/video/presign`);
    return data as ApProctoringVideoPresign;
  },
  proctoringVideoCommit: async (attemptId: string, key: string, reason: string) => {
    const { data } = await api.post(`${AP}/me/attempts/${attemptId}/proctoring/video/commit`, { key, reason });
    return data as { stored: boolean };
  },
  // Records the candidate's explicit webcam-proctoring consent (DPDP/GDPR) BEFORE the camera starts.
  // Owner-scoped + idempotent on the backend; stores only a timestamp + policy version.
  proctoringConsent: async (attemptId: string) => {
    const { data } = await api.post(`${AP}/me/attempts/${attemptId}/proctoring/consent`);
    return data as { consent: ApProctoringConsent | null };
  },
  // Beacon a client-side proctoring MEDIA upload failure (which step failed + why) so a reviewer can
  // see WHY a clip/snapshot is missing instead of a silent gap. Best-effort: telemetry must NEVER
  // throw into the exam, and the backend bounds/whitelists everything it stores.
  proctoringMediaError: async (attemptId: string, step: string, message?: string, statusCode?: number) => {
    try {
      await api.post(`${AP}/me/attempts/${attemptId}/proctoring/media-error`, {
        step,
        message: (message ?? "").slice(0, 200),
        status_code: statusCode ?? null,
      });
    } catch {
      // swallow — a failed error-beacon must not disrupt the exam
    }
```

## 2. Admin editor toggle — `src/app/dashboard/assessment-platform/[assessmentId]/edit/page.tsx`

Default-ON handling (lines 73–75), save mapping (line 94), and the checkbox UI (lines 352–353):

```tsx
      // Webcam AI proctoring defaults ON (matches the backend default) — a test with no explicit
      // requireWebcam is webcam-proctored; only an explicit false turns it off.
      proctorWebcam: proc.requireWebcam === undefined ? true : !!proc.requireWebcam,
      // ...
        requireWebcam: !!f("proctorWebcam"),
      // ...
                  <Checkbox checked={!!f("proctorWebcam")} onCheckedChange={(c) => setF("proctorWebcam", !!c)} />
                  Require webcam — AI proctoring (face / multiple-faces / phone / talking + snapshots &amp; clips)
```
