/**
 * Client-side webcam proctoring engine (MediaPipe Tasks Vision, all in-browser).
 *
 * Runs two models on the candidate's own webcam — so it scales for free (300 candidates =
 * 300 browsers doing the work, no server GPU):
 *   • FaceLandmarker  → face count (no-face / multiple-faces) + head pose (look-away)
 *   • ObjectDetector  → phone in frame
 *
 * Models + WASM are SELF-HOSTED under /models (the prod CSP is connect-src 'self', so
 * nothing loads from a CDN). Emits debounced, cooled-down events so a brief glance away or
 * a one-frame mis-detection doesn't spam the backend. This module is framework-agnostic;
 * the React wiring lives in webcam-proctor.tsx.
 */
import {
  FilesetResolver,
  FaceLandmarker,
  ObjectDetector,
  type FaceLandmarkerResult,
} from "@mediapipe/tasks-vision";

export type WebcamSignal = "look_away" | "multiple_faces" | "no_face" | "phone" | "talking";

export type DetectorCallbacks = {
  onSignal: (signal: WebcamSignal) => void;
  /** Live status for the on-screen indicator (not persisted). */
  onStatus?: (s: { faces: number; lookingAway: boolean; phone: boolean }) => void;
};

const WASM_PATH = "/models/mediapipe-wasm";
const FACE_MODEL = "/models/face_landmarker.task";
const OBJECT_MODEL = "/models/efficientdet_lite0.tflite";

// A signal must persist this many consecutive analyses before it fires (kills 1-frame blips).
const SUSTAIN = 3;
// Don't re-fire the same signal more than once per this window (ms) while it stays true.
const COOLDOWN_MS = 12_000;
// Head yaw/pitch (degrees) beyond which the candidate is "looking away".
const YAW_LIMIT = 28;
const PITCH_LIMIT = 22;
const PHONE_SCORE = 0.45;
// Talking = the jawOpen blendshape repeatedly crossing this open/closed threshold, not a
// single wide-open pose (a yawn opens once and stays open — it won't oscillate).
const MOUTH_OPEN_THRESHOLD = 0.15;
// Rolling window of recent open/closed samples (at FACE_INTERVAL_MS spacing) used to count
// mouth-state transitions, covering a few seconds of speech.
const MOUTH_WINDOW = 10;
// Open→closed (or closed→open) transitions required inside the window to call it "talking"
// rather than one static yawn.
const MOUTH_MIN_TRANSITIONS = 3;
// Analyse a few times per second — enough for proctoring, light on low-end laptops.
const FACE_INTERVAL_MS = 300;
const OBJECT_INTERVAL_MS = 1500;

/** Euler yaw/pitch (deg) from MediaPipe's 4x4 column-major facial transformation matrix. */
function headAngles(m: number[]): { yaw: number; pitch: number } {
  // Rotation is the upper-left 3x3 (column-major): r00=m[0], r10=m[1], r20=m[2], ...
  const r20 = m[2], r21 = m[6], r22 = m[10];
  const pitch = Math.atan2(-r21, Math.sqrt(r20 * r20 + r22 * r22)) * (180 / Math.PI);
  const yaw = Math.atan2(r20, r22) * (180 / Math.PI);
  return { yaw, pitch };
}

export class WebcamDetector {
  private face: FaceLandmarker | null = null;
  private object: ObjectDetector | null = null;
  private raf = 0;
  private running = false;
  private lastFace = 0;
  private lastObject = 0;
  private streak: Record<WebcamSignal, number> = { look_away: 0, multiple_faces: 0, no_face: 0, phone: 0, talking: 0 };
  private firedAt: Record<WebcamSignal, number> = { look_away: 0, multiple_faces: 0, no_face: 0, phone: 0, talking: 0 };
  private phonePresent = false;
  // Rolling open/closed samples of the jawOpen blendshape, used to detect sustained
  // mouth-movement (talking) rather than a single static open mouth (yawn).
  private mouthOpenHistory: boolean[] = [];

  async init(): Promise<void> {
    const vision = await FilesetResolver.forVisionTasks(WASM_PATH);
    this.face = await FaceLandmarker.createFromOptions(vision, {
      baseOptions: { modelAssetPath: FACE_MODEL },
      runningMode: "VIDEO",
      numFaces: 3,
      outputFacialTransformationMatrixes: true,
      outputFaceBlendshapes: true,
    });
    this.object = await ObjectDetector.createFromOptions(vision, {
      baseOptions: { modelAssetPath: OBJECT_MODEL },
      runningMode: "VIDEO",
      scoreThreshold: PHONE_SCORE,
      maxResults: 5,
    });
  }

  start(video: HTMLVideoElement, cb: DetectorCallbacks): void {
    if (this.running) return;
    this.running = true;
    const loop = () => {
      if (!this.running) return;
      const now = performance.now();
      if (video.readyState >= 2 && this.face && now - this.lastFace >= FACE_INTERVAL_MS) {
        this.lastFace = now;
        try { this.analyseFace(this.face.detectForVideo(video, now), cb); } catch { /* transient */ }
      }
      if (video.readyState >= 2 && this.object && now - this.lastObject >= OBJECT_INTERVAL_MS) {
        this.lastObject = now;
        try { this.analyseObjects(this.object.detectForVideo(video, now), cb); } catch { /* transient */ }
      }
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  private fire(signal: WebcamSignal, active: boolean, cb: DetectorCallbacks): void {
    if (!active) { this.streak[signal] = 0; return; }
    this.streak[signal] += 1;
    if (this.streak[signal] < SUSTAIN) return;
    const now = Date.now();
    if (now - this.firedAt[signal] < COOLDOWN_MS) return;
    this.firedAt[signal] = now;
    cb.onSignal(signal);
  }

  private analyseFace(res: FaceLandmarkerResult, cb: DetectorCallbacks): void {
    const faces = res.faceLandmarks?.length ?? 0;
    let lookingAway = false;
    if (faces === 1) {
      const m = res.facialTransformationMatrixes?.[0]?.data;
      if (m) {
        const { yaw, pitch } = headAngles(Array.from(m));
        lookingAway = Math.abs(yaw) > YAW_LIMIT || Math.abs(pitch) > PITCH_LIMIT;
      }
    }
    this.fire("no_face", faces === 0, cb);
    this.fire("multiple_faces", faces > 1, cb);
    this.fire("look_away", lookingAway, cb);
    this.fire("talking", this.mouthMoving(res, faces), cb);
    cb.onStatus?.({ faces, lookingAway, phone: this.phonePresent });
  }

  /**
   * True when the jawOpen blendshape has crossed the open/closed threshold repeatedly within
   * the recent sample window — i.e. the mouth is opening and closing (talking), not just
   * sitting open once (a yawn opens and stays open, producing at most one transition).
   */
  private mouthMoving(res: FaceLandmarkerResult, faces: number): boolean {
    if (faces !== 1) {
      this.mouthOpenHistory.length = 0;
      return false;
    }
    const jawOpen = res.faceBlendshapes?.[0]?.categories?.find((c) => c.categoryName === "jawOpen")?.score ?? 0;
    this.mouthOpenHistory.push(jawOpen > MOUTH_OPEN_THRESHOLD);
    if (this.mouthOpenHistory.length > MOUTH_WINDOW) this.mouthOpenHistory.shift();
    let transitions = 0;
    for (let i = 1; i < this.mouthOpenHistory.length; i++) {
      if (this.mouthOpenHistory[i] !== this.mouthOpenHistory[i - 1]) transitions++;
    }
    return transitions >= MOUTH_MIN_TRANSITIONS;
  }

  private analyseObjects(res: { detections?: Array<{ categories?: Array<{ categoryName?: string; score?: number }> }> }, cb: DetectorCallbacks): void {
    const phone = (res.detections ?? []).some((d) =>
      (d.categories ?? []).some((c) => /cell phone|mobile phone|phone/i.test(c.categoryName ?? "") && (c.score ?? 0) >= PHONE_SCORE),
    );
    this.phonePresent = phone;
    this.fire("phone", phone, cb);
  }

  stop(): void {
    this.running = false;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
  }

  close(): void {
    this.stop();
    this.face?.close();
    this.object?.close();
    this.face = null;
    this.object = null;
  }
}
