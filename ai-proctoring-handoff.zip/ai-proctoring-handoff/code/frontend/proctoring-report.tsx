"use client";

import { useMemo, useState } from "react";
import type { ApProctoringReport } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { ShieldAlert, ShieldCheck, Camera, Search, Video } from "lucide-react";

// Human labels for every event/snapshot reason.
const LABELS: Record<string, string> = {
  tab_switch: "Switched tab / window",
  fullscreen_exit: "Left full screen",
  copy: "Copy / paste / right-click",
  blur: "Window lost focus",
  look_away: "Looked away from screen",
  multiple_faces: "Multiple faces in frame",
  no_face: "No face detected",
  phone: "Phone detected",
  talking: "Talking / lip movement",
  periodic: "Routine snapshot",
  start: "Start snapshot",
};
// Count-key → label, in display order.
const COUNTS: [keyof ApProctoringReport["counts"], string][] = [
  ["lookAways", "Looked away"],
  ["multipleFaces", "Multiple faces"],
  ["noFace", "No face"],
  ["phoneDetections", "Phone"],
  ["talkingEvents", "Talking / lip movement"],
  ["tabSwitches", "Tab switches"],
  ["fullscreenExits", "Fullscreen exits"],
  ["copyAttempts", "Copy/paste"],
  ["blurEvents", "Window blurs"],
];

const fmtTime = (iso: string) => {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? iso : d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
};
const fmtDateTime = (iso: string) => {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? iso : d.toLocaleString();
};
const label = (k: string) => LABELS[k] ?? k;

export function ProctoringReport({ report }: { report: ApProctoringReport }) {
  const [query, setQuery] = useState("");
  const [zoom, setZoom] = useState<string | null>(null);

  const q = query.trim().toLowerCase();
  const totalFlags = useMemo(
    () => Object.values(report.counts ?? {}).reduce((a, b) => a + (b || 0), 0),
    [report.counts],
  );

  // Snapshots (newest first) filtered by the warning that captured them.
  const snapshots = useMemo(() => {
    const list = [...(report.snapshots ?? [])].sort((a, b) => (a.at < b.at ? 1 : -1));
    if (!q) return list;
    return list.filter((s) => label(s.reason).toLowerCase().includes(q) || s.reason.toLowerCase().includes(q));
  }, [report.snapshots, q]);

  // Event timeline (newest first) filtered by type.
  const events = useMemo(() => {
    const list = [...(report.events ?? [])].sort((a, b) => (a.at < b.at ? 1 : -1));
    if (!q) return list;
    return list.filter((e) => label(e.type).toLowerCase().includes(q) || e.type.toLowerCase().includes(q));
  }, [report.events, q]);

  // Violation video clips (newest first) filtered by the warning that captured them.
  const videos = useMemo(() => {
    const list = [...(report.videos ?? [])].sort((a, b) => (a.at < b.at ? 1 : -1));
    if (!q) return list;
    return list.filter((v) => label(v.reason).toLowerCase().includes(q) || v.reason.toLowerCase().includes(q));
  }, [report.videos, q]);

  const hasAny =
    totalFlags > 0 ||
    (report.snapshots?.length ?? 0) > 0 ||
    (report.events?.length ?? 0) > 0 ||
    (report.videos?.length ?? 0) > 0;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <ShieldAlert className="size-4 text-amber-600" /> Proctoring &amp; Integrity
          {totalFlags > 0 && <Badge variant="outline" className="ml-1 text-amber-600">{totalFlags} flag(s)</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* DPDP/GDPR: whether/when the candidate consented to webcam recording. */}
        {report.consent?.at ? (
          <p className="flex items-center gap-1.5 text-xs font-medium text-emerald-600">
            <ShieldCheck className="size-3.5" /> Consent recorded {fmtDateTime(report.consent.at)}
          </p>
        ) : (
          <p className="flex items-center gap-1.5 text-xs font-medium text-amber-600">
            <ShieldAlert className="size-3.5" /> No consent recorded
          </p>
        )}
        {/* Why a clip/snapshot is missing: client-reported media-upload failures. Shown even when no
            media was captured, so a silent gap becomes an explained one. */}
        {(report.mediaErrors?.length ?? 0) > 0 && (
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs">
            <p className="mb-1 flex items-center gap-1.5 font-medium text-amber-700">
              <ShieldAlert className="size-3.5" /> Recording upload issues ({report.mediaErrors?.length ?? 0})
            </p>
            <ul className="space-y-0.5 text-amber-700/90">
              {(report.mediaErrors ?? []).slice(-6).reverse().map((e, i) => (
                <li key={i} className="font-mono">
                  {fmtDateTime(e.at)} — {e.step}{e.status ? ` (HTTP ${e.status})` : ""}{e.message ? `: ${e.message}` : ""}
                </li>
              ))}
            </ul>
          </div>
        )}
        {!hasAny ? (
          <p className="text-sm text-muted-foreground">No proctoring activity was recorded for this attempt.</p>
        ) : (
          <>
            {/* Counts */}
            <div className="flex flex-wrap gap-2">
              {COUNTS.filter(([k]) => (report.counts?.[k] ?? 0) > 0).map(([k, lbl]) => (
                <Badge key={k} variant="outline" className="text-amber-600">{lbl}: {report.counts[k]}</Badge>
              ))}
              {totalFlags === 0 && <span className="text-sm text-muted-foreground">No flags — clean attempt.</span>}
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search flags / snapshots (e.g. phone, looked away, tab)…"
                className="pl-8"
              />
            </div>

            {/* Snapshot gallery — each labelled with the warning that captured it + time */}
            {snapshots.length > 0 && (
              <div>
                <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                  <Camera className="size-3.5" /> Webcam snapshots ({snapshots.length})
                </p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 md:grid-cols-5">
                  {snapshots.map((s, i) => (
                    <button key={`${s.url}-${i}`} type="button" onClick={() => setZoom(s.url)} className="group text-left">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={s.url} alt={label(s.reason)} className="aspect-video w-full rounded-md object-cover ring-1 ring-border transition group-hover:ring-primary" />
                      <p className={`mt-1 truncate text-[11px] ${s.reason === "periodic" || s.reason === "start" ? "text-muted-foreground" : "font-medium text-amber-600"}`}>
                        {label(s.reason)}
                      </p>
                      <p className="text-[10px] text-muted-foreground">{fmtTime(s.at)}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Violation video clips — short webm recordings served via presigned S3 GET */}
            {videos.length > 0 && (
              <div>
                <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                  <Video className="size-3.5" /> Violation clips ({videos.length})
                </p>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {videos.map((v, i) => (
                    <div key={`${v.url}-${i}`}>
                      <video
                        src={v.url}
                        controls
                        preload="metadata"
                        className="aspect-video w-full rounded-md bg-black object-cover ring-1 ring-border"
                      />
                      <p className="mt-1 truncate text-[11px] font-medium text-amber-600">{label(v.reason)}</p>
                      <p className="text-[10px] text-muted-foreground">{fmtTime(v.at)}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Event timeline */}
            {events.length > 0 && (
              <div>
                <p className="mb-2 text-xs font-medium text-muted-foreground">Event timeline ({events.length})</p>
                <div className="max-h-64 space-y-1 overflow-y-auto rounded-lg border border-border/70 p-2">
                  {events.map((e, i) => (
                    <div key={`${e.at}-${i}`} className="flex items-center justify-between gap-2 text-xs">
                      <span className={/tab_switch|fullscreen|copy|blur|phone|multiple|no_face|look|talking/.test(e.type) ? "text-amber-600" : ""}>{label(e.type)}</span>
                      <span className="shrink-0 tabular-nums text-muted-foreground">{fmtTime(e.at)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {snapshots.length === 0 && events.length === 0 && videos.length === 0 && q && (
              <p className="text-sm text-muted-foreground">No flags match &quot;{query}&quot;.</p>
            )}
          </>
        )}
      </CardContent>

      <Dialog open={!!zoom} onOpenChange={(o) => !o && setZoom(null)}>
        <DialogContent className="sm:max-w-2xl">
          {zoom && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={zoom} alt="Webcam snapshot" className="w-full rounded-lg" />
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}
