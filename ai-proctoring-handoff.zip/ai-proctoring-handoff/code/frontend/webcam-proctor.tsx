"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { WebcamDetector, type WebcamSignal } from "@/lib/proctoring/webcam-detector";
import { ClipRecorder } from "@/lib/proctoring/clip-recorder";
import { assessmentPlatformApi } from "@/lib/api";
import { Video, VideoOff, Loader2, ShieldAlert } from "lucide-react";

type Props = {
  /** Attempt this camera belongs to — used to presign/commit violation clips (owner-scoped). */
  attemptId: string;
  /** Parent records this as a proctoring event (look_away / multiple_faces / no_face / phone). */
  onSignal: (signal: WebcamSignal) => void;
  /** Fires once when camera is granted + models are loaded (true) or on fatal error (false). */
  onReady?: (ready: boolean) => void;
};

const SNAPSHOT_EVERY_MS = 25_000;   // periodic evidence frame
const SNAPSHOT_MIN_GAP_MS = 12_000; // throttle on-signal snapshots
const SNAP_WIDTH = 320;             // downscale — thumbnails, not recordings
const CLIP_LENGTH_MS = 7_000;       // length of each fresh violation clip (audio+video)

export function WebcamProctor({ attemptId, onSignal, onReady }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const detectorRef = useRef<WebcamDetector | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<ClipRecorder | null>(null);
  const lastSnapRef = useRef(0);
  // Dedup for the media-error beacon: each distinct failing step is reported at most once per window,
  // so a persistent failure (e.g. every snapshot POST failing) yields one diagnostic row, not a flood.
  const reportedRef = useRef<Map<string, number>>(new Map());

  // Proctoring uploads are best-effort and were previously swallowed silently — a missing clip looked
  // identical to a clean attempt. This beacon surfaces WHICH step failed to the reviewer's report.
  const reportMediaError = useCallback((step: string, message?: string, statusCode?: number) => {
    const now = Date.now();
    if (now - (reportedRef.current.get(step) ?? 0) < 30_000) return;
    reportedRef.current.set(step, now);
    void assessmentPlatformApi.proctoringMediaError(attemptId, step, message, statusCode);
  }, [attemptId]);
  const [phase, setPhase] = useState<"loading" | "on" | "denied" | "error">("loading");
  const [status, setStatus] = useState<{ faces: number; lookingAway: boolean; phone: boolean }>(
    { faces: 1, lookingAway: false, phone: false },
  );
  // DPDP/GDPR: the camera must NOT start until the candidate has actively, explicitly consented to
  // webcam proctoring + recording. `consented` gates getUserMedia; `agreed` tracks the checkbox;
  // `declined` shows the "cannot proceed without consent" affordance.
  const [consented, setConsented] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [declined, setDeclined] = useState(false);

  const acceptConsent = useCallback(() => {
    // Record consent (best-effort) BEFORE the camera starts, but ONLY after the candidate actively
    // consented. A transient network failure must not block the exam, so proceed regardless.
    void assessmentPlatformApi.proctoringConsent(attemptId).catch(() => {});
    setConsented(true);
  }, [attemptId]);

  const snapshot = useCallback((reason: string, force = false) => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    if (video.readyState < 2) {
      // Camera hasn't delivered a decodable frame yet — record it so a run that never produces a
      // snapshot is diagnosable rather than a silent gap. The periodic timer will retry.
      reportMediaError("snapshot-not-ready", `readyState=${video.readyState}`);
      return;
    }
    const now = Date.now();
    if (!force && now - lastSnapRef.current < SNAPSHOT_MIN_GAP_MS) return;
    lastSnapRef.current = now;
    const scale = SNAP_WIDTH / (video.videoWidth || SNAP_WIDTH);
    canvas.width = SNAP_WIDTH;
    canvas.height = Math.round((video.videoHeight || 240) * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob((blob) => {
      if (!blob || blob.size === 0) { reportMediaError("snapshot-empty"); return; }
      // Upload straight from here (owner-scoped API) so every failure is instrumented; best-effort —
      // a dropped snapshot must never interrupt the exam.
      void assessmentPlatformApi
        .proctoringSnapshot(attemptId, blob, reason)
        .then((r) => { if (!r?.stored) reportMediaError("snapshot-not-stored"); })
        .catch((e: unknown) => {
          const err = e as { message?: string; response?: { status?: number } };
          reportMediaError("snapshot-error", err?.message ?? String(e), err?.response?.status);
        });
    }, "image/jpeg", 0.6);
  }, [attemptId, reportMediaError]);

  // On a violation, upload the last ~10s webcam clip DIRECT to S3 (presign → POST → commit). Every
  // step is best-effort and fully detached — recording/uploading evidence must NEVER interrupt,
  // block, or slow the exam. A ≥30s cooldown keeps clip volume bounded during repeated flags.
  const captureViolationClip = useCallback((reason: string) => {
    const recorder = recorderRef.current;
    if (!recorder) { reportMediaError("recorder-unsupported"); return; }
    // No fixed cooldown — every distinct violation window gets a clip. A flag that fires while a clip
    // is already recording is covered by that in-flight clip, so we simply skip starting a second one.
    if (recorder.isBusy()) return;
    void (async () => {
      try {
        // Record a fresh ~7s audio+video segment starting now (one continuous session = valid webm).
        const clip = await recorder.captureClip(CLIP_LENGTH_MS);
        if (!clip || clip.size === 0) { reportMediaError("clip-empty"); return; }
        let presign;
        try {
          presign = await assessmentPlatformApi.proctoringVideoPresign(attemptId);
        } catch (e) {
          reportMediaError("presign-error", (e as { message?: string })?.message ?? String(e),
            (e as { response?: { status?: number } })?.response?.status);
          return;
        }
        if (!presign?.url || !presign.fields || !presign.key) { reportMediaError("presign-null"); return; }
        const form = new FormData();
        // S3 requires every policy field BEFORE the file field.
        Object.entries(presign.fields).forEach(([k, v]) => form.append(k, v));
        form.append("file", clip, "clip.webm");
        let res: Response;
        try {
          res = await fetch(presign.url, { method: "POST", body: form });
        } catch (e) {
          // A cross-origin fetch that S3 rejects at the CORS layer throws here (TypeError) — this is
          // exactly the signal that would otherwise be invisible.
          reportMediaError("s3-post-error", (e as { message?: string })?.message ?? String(e));
          return;
        }
        if (!res.ok) { reportMediaError("s3-post-failed", `size=${clip.size}`, res.status); return; }
        try {
          await assessmentPlatformApi.proctoringVideoCommit(attemptId, presign.key, reason);
        } catch (e) {
          reportMediaError("commit-error", (e as { message?: string })?.message ?? String(e),
            (e as { response?: { status?: number } })?.response?.status);
        }
      } catch (e) {
        reportMediaError("capture-error", (e as { message?: string })?.message ?? String(e));
      }
    })();
  }, [attemptId, reportMediaError]);

  useEffect(() => {
    // Hard gate: no getUserMedia / camera / recording until the candidate has actively consented.
    if (!consented) return;
    let cancelled = false;
    const detector = new WebcamDetector();
    detectorRef.current = detector;

    (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          // 720p for clearer violation clips; the detector downsamples internally so this is fine.
          video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" },
          // Microphone IS captured now (consented) so violation clips include audio. Echo-cancel +
          // noise-suppress keep it clean; the on-screen <video> preview stays muted so there's no feedback.
          audio: { echoCancellation: true, noiseSuppression: true },
        });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        const video = videoRef.current;
        if (video) {
          video.srcObject = stream;
          await video.play().catch(() => {});
        }
        await detector.init();
        if (cancelled) return;
        // Only attaches when this browser supports MediaRecorder + a webm codec; otherwise a silent
        // no-op. The recorder captures a fresh audio+video clip on demand (per violation).
        if (ClipRecorder.isSupported()) {
          recorderRef.current = new ClipRecorder();
          recorderRef.current.attach(stream);
        }
        if (video) {
          detector.start(video, {
            onSignal: (s) => { onSignal(s); snapshot(s); captureViolationClip(s); },
            onStatus: setStatus,
          });
        }
        setPhase("on");
        onReady?.(true);
        // First evidence frame shortly after start, then on an interval.
        window.setTimeout(() => snapshot("start", true), 1500);
      } catch (e) {
        if (cancelled) return;
        const err = e as { name?: string };
        setPhase(err.name === "NotAllowedError" || err.name === "SecurityError" ? "denied" : "error");
        onReady?.(false);
      }
    })();

    return () => {
      cancelled = true;
      detector.close();
      recorderRef.current?.stop();
      recorderRef.current = null;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, [consented, onSignal, onReady, snapshot, captureViolationClip]);

  // Periodic evidence snapshots.
  useEffect(() => {
    if (phase !== "on") return;
    const t = window.setInterval(() => snapshot("periodic"), SNAPSHOT_EVERY_MS);
    return () => window.clearInterval(t);
  }, [phase, snapshot]);

  // Blocking consent gate — rendered until the candidate actively consents. The camera stays off
  // (getUserMedia is gated on `consented`) while this is shown.
  if (!consented) {
    return (
      <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
        <div className="w-full max-w-md rounded-2xl border border-border bg-background p-6 shadow-2xl">
          {declined ? (
            <div className="space-y-3 text-center">
              <ShieldAlert className="mx-auto size-8 text-red-600" />
              <h2 className="text-lg font-semibold">Consent is required to continue</h2>
              <p className="text-sm text-muted-foreground">
                This is a proctored exam. It cannot proceed without your consent to webcam and
                microphone proctoring and recording. To continue with the exam, please provide consent.
              </p>
              <button
                type="button"
                onClick={() => setDeclined(false)}
                className="mx-auto rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
              >
                Back to consent
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Video className="size-5 text-blue-600" />
                <h2 className="text-lg font-semibold">Webcam &amp; microphone proctoring consent</h2>
              </div>
              <p className="text-sm text-muted-foreground">
                This exam is proctored. Your webcam <strong>video and microphone audio</strong> will be
                recorded for exam-integrity purposes for the duration of this attempt. Recordings are
                stored securely, retained for a limited period, and accessible only to authorized reviewers.
              </p>
              <label className="flex items-start gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="mt-0.5 size-4 shrink-0 accent-blue-600"
                />
                <span>I have read and consent to webcam and microphone proctoring and recording.</span>
              </label>
              <div className="flex flex-col gap-2 sm:flex-row-reverse">
                <button
                  type="button"
                  disabled={!agreed}
                  onClick={acceptConsent}
                  className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  I consent — start proctoring
                </button>
                <button
                  type="button"
                  onClick={() => setDeclined(true)}
                  className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-muted"
                >
                  I do not consent
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  const denied = phase === "denied" || phase === "error";
  return (
    <>
      {/* Live self-view — fixed bottom-right so the candidate can SEE their camera is on and
          being monitored. The <video> must stay mounted while the camera is active so the
          stream/detector keep running; it's mirrored like a normal selfie. */}
      {!denied && (
        <div className="fixed bottom-4 right-4 z-[60] w-44 overflow-hidden rounded-xl border border-blue-500/50 bg-black shadow-xl">
          <video ref={videoRef} playsInline muted className="block h-32 w-full -scale-x-100 bg-black object-cover" />
          <div className="flex items-center justify-between gap-1 bg-black/80 px-2 py-1 text-[11px] font-medium">
            <span className="flex items-center gap-1 text-white/90"><Video className="size-3" /> Proctoring</span>
            {phase === "loading" ? (
              <span className="flex items-center gap-1 text-blue-200"><Loader2 className="size-3 animate-spin" /> Starting…</span>
            ) : status.faces === 0 ? (
              <span className="text-amber-300">No face</span>
            ) : status.faces > 1 ? (
              <span className="text-amber-300">Multiple faces</span>
            ) : status.phone ? (
              <span className="text-amber-300">Phone seen</span>
            ) : status.lookingAway ? (
              <span className="text-amber-300">Look at screen</span>
            ) : (
              <span className="flex items-center gap-1 text-white"><span className="size-1.5 rounded-full bg-red-500 animate-pulse" /> REC</span>
            )}
          </div>
        </div>
      )}
      <canvas ref={canvasRef} className="hidden" />

      {/* Inline status line in the proctoring banner row. */}
      {denied ? (
        <div className="flex items-center gap-2 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-1.5 text-xs text-red-600">
          <VideoOff className="size-3.5 shrink-0" />
          {phase === "denied"
            ? "Camera access is required for this proctored test. Enable it in your browser and reload."
            : "Camera could not start. Close other apps using it, then reload."}
        </div>
      ) : (
        <div className="flex items-center gap-2 rounded-lg border border-blue-500/30 bg-blue-500/5 px-3 py-1.5 text-xs">
          <span className="flex items-center gap-1.5 text-blue-700"><Video className="size-3.5" /> {phase === "loading" ? "Starting camera…" : "Camera on — you're being proctored"}</span>
          {status.faces === 0 && phase === "on" && <span className="flex items-center gap-1 text-amber-600"><ShieldAlert className="size-3" /> No face detected</span>}
          {status.faces > 1 && <span className="flex items-center gap-1 text-amber-600"><ShieldAlert className="size-3" /> Multiple faces</span>}
          {status.phone && <span className="flex items-center gap-1 text-amber-600"><ShieldAlert className="size-3" /> Phone detected</span>}
        </div>
      )}
    </>
  );
}
