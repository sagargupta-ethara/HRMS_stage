// On-demand webcam clip recorder for proctoring. On a violation the player calls captureClip(), which
// records ONE fresh, self-contained ~7s segment (audio + video) from the live proctor stream and
// returns the assembled Blob. Because each clip is a single continuous MediaRecorder session, the webm
// is always valid + clean — no ring-buffer splicing (which produced corrupt/garbled/duplicate clips).
// Every method is a defensive no-op when MediaRecorder / a webm codec is unavailable, so an
// unsupported browser can never break the exam.

const VIDEO_BPS = 1_500_000; // ~good quality at 720p; ~1.3MB for a 7s clip (well under the 10MB S3 cap)
const AUDIO_BPS = 96_000;
const DEFAULT_CLIP_MS = 7_000;

// Prefer a webm mime that carries BOTH video (vp8/vp9) and audio (opus). Falls back to video-only, then
// bare webm, so the recorder still works where opus muxing isn't offered.
const MIME_CANDIDATES = [
  "video/webm;codecs=vp8,opus",
  "video/webm;codecs=vp9,opus",
  "video/webm;codecs=vp8",
  "video/webm",
];

function pickMime(): string | null {
  if (typeof MediaRecorder === "undefined" || typeof MediaRecorder.isTypeSupported !== "function") {
    return null;
  }
  for (const m of MIME_CANDIDATES) {
    if (MediaRecorder.isTypeSupported(m)) return m;
  }
  return null;
}

export class ClipRecorder {
  private stream: MediaStream | null = null;
  private recording = false;
  private readonly mime = pickMime();

  /** True only when MediaRecorder and at least one webm codec are supported by this browser. */
  static isSupported(): boolean {
    return pickMime() !== null;
  }

  /** Point the recorder at the live proctor stream (audio + video). Call once after getUserMedia. */
  attach(stream: MediaStream): void {
    this.stream = stream;
  }

  /** A clip is currently being recorded — a concurrent violation is covered by that in-flight clip. */
  isBusy(): boolean {
    return this.recording;
  }

  /**
   * Record a fresh `durationMs` clip (audio + video) and resolve with the Blob, or null when the
   * recorder is unavailable / already busy / produced no data. One continuous session ⇒ valid webm.
   */
  captureClip(durationMs: number = DEFAULT_CLIP_MS): Promise<Blob | null> {
    if (!this.stream || this.recording || !this.mime) return Promise.resolve(null);
    this.recording = true;
    return new Promise<Blob | null>((resolve) => {
      const chunks: Blob[] = [];
      let rec: MediaRecorder;
      try {
        rec = new MediaRecorder(this.stream!, {
          mimeType: this.mime!,
          videoBitsPerSecond: VIDEO_BPS,
          audioBitsPerSecond: AUDIO_BPS,
        });
      } catch {
        this.recording = false;
        resolve(null);
        return;
      }
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        this.recording = false;
        resolve(chunks.length ? new Blob(chunks, { type: "video/webm" }) : null);
      };
      rec.ondataavailable = (e) => { if (e.data && e.data.size > 0) chunks.push(e.data); };
      rec.onstop = finish;
      rec.onerror = finish;
      try {
        rec.start(); // no timeslice — a single dataavailable fires on stop with the full segment
      } catch {
        this.recording = false;
        resolve(null);
        return;
      }
      window.setTimeout(() => {
        try {
          if (rec.state !== "inactive") rec.stop();
          else finish();
        } catch {
          finish();
        }
      }, durationMs);
    });
  }

  /** Drop the stream reference. Any in-flight capture resolves on its own recorder stop. */
  stop(): void {
    this.stream = null;
    this.recording = false;
  }
}
