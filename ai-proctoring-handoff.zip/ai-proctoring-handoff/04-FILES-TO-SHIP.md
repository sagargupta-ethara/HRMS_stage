# Files to Ship — Complete Inventory

Everything that makes up the AI proctoring feature, grouped by repo. "Copy in this folder" = a verbatim copy exists under [code/](code/). For files shared with the rest of the Assessment Platform, the proctoring line ranges are given (line numbers as of 14 Jul 2026) and the key sections are excerpted in [code/frontend/proctoring-frontend-excerpts.md](code/frontend/proctoring-frontend-excerpts.md) / [code/backend/proctoring-backend-excerpts.md](code/backend/proctoring-backend-excerpts.md).

## Frontend — `main-app/ethara-hrms/`

### Proctoring-specific files (ship whole; copied into this folder)

| File | Role | Copy |
|---|---|---|
| `src/lib/proctoring/webcam-detector.ts` | AI detection engine — MediaPipe FaceLandmarker + ObjectDetector, thresholds, debounce/cooldown, signal emission | [code/frontend/webcam-detector.ts](code/frontend/webcam-detector.ts) |
| `src/lib/proctoring/clip-recorder.ts` | On-demand 7 s audio+video webm clip recorder (MediaRecorder), codec negotiation, defensive no-ops | [code/frontend/clip-recorder.ts](code/frontend/clip-recorder.ts) |
| `src/components/assessment-platform/webcam-proctor.tsx` | React wiring — consent gate, getUserMedia, snapshots, clip presign→S3→commit pipeline, media-error beacon, self-view UI | [code/frontend/webcam-proctor.tsx](code/frontend/webcam-proctor.tsx) |
| `src/components/assessment-platform/proctoring-report.tsx` | Reviewer integrity report — count chips, timeline, snapshot gallery, clip playback, media-error list | [code/frontend/proctoring-report.tsx](code/frontend/proctoring-report.tsx) |

### Integration & shared files (proctoring sections)

| File | Proctoring content | Where |
|---|---|---|
| `src/components/assessment-platform/attempt-player.tsx` | Mounts `WebcamProctor`; classic anti-cheat (tab/fullscreen/copy listeners ~lines 84–282), warning counter + auto-submit, instructions banner (~394–402), status bar (~473–491) | full copy: [code/frontend/attempt-player.tsx](code/frontend/attempt-player.tsx) |
| `src/lib/api.ts` | Client methods `proctoringEvent / proctoringSnapshot / proctoringVideoPresign / proctoringVideoCommit / proctoringConsent / proctoringMediaError` (lines ~5239–5280) + types `ApProctoringConfig/Counts/Report` (~4847, 4974–5011) | excerpt in frontend-excerpts.md |
| `src/app/dashboard/assessment-platform/[assessmentId]/edit/page.tsx` | "Require webcam — AI proctoring" toggle; default-ON mapping (lines ~73–75, 94, 352–353) | excerpt in frontend-excerpts.md |
| `src/app/dashboard/assessment-platform/[assessmentId]/results/[attemptId]/page.tsx` | Renders `<ProctoringReport>` on the results page | reference only |
| `src/app/dashboard/assessment-platform/grading/[attemptId]/page.tsx` | Renders `<ProctoringReport>` on the grading page | reference only |
| `src/components/assessment-platform/attempt-player.test.tsx` | Player tests incl. proctoring wiring | reference only |
| `package.json` | dependency `"@mediapipe/tasks-vision": "^0.10.35"` | reference only |

### Static model assets (ship as-is; ~41 MB total, not copied here)

| Path | Size |
|---|---|
| `public/models/face_landmarker.task` | 3.6 MB |
| `public/models/efficientdet_lite0.tflite` | 4.4 MB |
| `public/models/mediapipe-wasm/` (6 files: SIMD + no-SIMD `vision_wasm_*.{js,wasm}`) | 33 MB |

## Backend — `main-app/ethara-hrms-api/`

| File | Proctoring content | Where |
|---|---|---|
| `app/services/assessment_platform.py` | Lines 51–219: defaults (`requireWebcam: True`), `proctoring_config`, `proctoring_counts`, `serialize_proctoring_report` (presigned GETs), `record_proctoring_event/_snapshot/_video/_consent/_media_error`; report wired into attempt serializers (~701, 1068, 1140–1141, 1201) | excerpt in [backend-excerpts.md](code/backend/proctoring-backend-excerpts.md) |
| `app/api/routes/assessment_platform.py` | Lines 1960–2139: the six candidate endpoints (event, consent, snapshot, presign, commit, media-error) + `_proctor_s3_client`, size caps, rate limits; settings-update endpoint (~460) accepts the proctoring config | excerpt in backend-excerpts.md |
| `app/schemas/assessment_platform.py` | `ProctoringEventRequest` (line ~194) | excerpt in backend-excerpts.md |
| `app/db/models.py` | `ApAttempt.proctoring` JSON column (line ~2211) | excerpt in backend-excerpts.md |
| `alembic/versions/f3a7c9e1d5b8_ap_attempt_proctoring.py` | Migration adding the column | full copy: [code/backend/f3a7c9e1d5b8_ap_attempt_proctoring.py](code/backend/f3a7c9e1d5b8_ap_attempt_proctoring.py) |
| `tests/test_assessment_platform_extra.py` | Backend proctoring tests | reference only |

## Config / infra checklist (not files, but required to run)

- `AWS_S3_BUCKET` (+ region/credentials) — evidence storage; prod uses `ethara-hrms-doc`
- S3 bucket CORS: allow `POST` (clip upload) and `GET` (presigned playback) from the app origin
- CSP: `img-src`/`media-src`/`connect-src` must allow the S3 endpoint; models stay same-origin under `/models`
- DB: `alembic upgrade head` (adds `ap_attempts.proctoring`)
- Deploy: API restart (systemd `ethara-hrms-api`) + frontend `npm run build` && restart (systemd `ethara-hrms-frontend`)
