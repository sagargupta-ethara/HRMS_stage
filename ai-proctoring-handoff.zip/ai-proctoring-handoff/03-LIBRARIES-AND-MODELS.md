# Libraries, Models & APIs Used

## The one third-party AI library

### `@mediapipe/tasks-vision` `^0.10.35` (Google MediaPipe Tasks — Vision)

The entire AI layer is this single npm package (declared in `main-app/ethara-hrms/package.json`). It ships a WASM inference runtime that executes TFLite models **inside the browser** — no server, no GPU, no per-call cost. Two of its task classes are used, both created from `FilesetResolver.forVisionTasks()` in `runningMode: "VIDEO"`:

| Task class | Model file | Size | What it provides here |
|---|---|---|---|
| `FaceLandmarker` | `face_landmarker.task` | 3.6 MB | face count (up to 3), **facial transformation matrix** (→ head yaw/pitch for look-away), **blendshapes** (`jawOpen` → talking detection) |
| `ObjectDetector` | `efficientdet_lite0.tflite` (EfficientDet-Lite0, COCO-trained) | 4.4 MB | generic object detection; we match categories `/cell phone|mobile phone|phone/i` at score ≥ 0.45 |

**Self-hosted assets** (required by the prod CSP `connect-src 'self'` — nothing may load from Google's CDN), all under `main-app/ethara-hrms/public/models/`:

```
public/models/
├── face_landmarker.task          3.6 MB   FaceLandmarker model
├── efficientdet_lite0.tflite     4.4 MB   ObjectDetector model
└── mediapipe-wasm/               33 MB    WASM runtime (SIMD + no-SIMD variants:
                                           vision_wasm_internal.{js,wasm}, …)
```

> Shipping note: these binaries are static frontend assets. If you copy the feature to another app, copy this folder too (or re-download the same versions from the MediaPipe model zoo) and keep the three path constants in `webcam-detector.ts` (`WASM_PATH`, `FACE_MODEL`, `OBJECT_MODEL`) pointing at your hosting path.

**Why MediaPipe (and not the alternatives):**
- Client-side by design → 300 candidates = 300 browsers doing inference; the server sees only events. A server-side pipeline (OpenCV/torch on frames) would need GPU capacity and frame streaming for every live attempt.
- One package covers both needs (face geometry **and** object detection) — no TensorFlow.js model-zoo assembly.
- Face landmarker's transformation matrix gives head pose directly — no separate pose-estimation model.
- Self-hostable WASM + models — CSP-compatible, no third-party calls from the exam page (also a privacy win).

## Browser-native APIs (no libraries)

| API | Used for |
|---|---|
| `navigator.mediaDevices.getUserMedia` | 720p webcam + mic (echo-cancellation & noise-suppression constraints on) — only after consent |
| `MediaRecorder` | 7 s violation clips; mime negotiation tries `video/webm;codecs=vp8,opus` → `vp9,opus` → video-only → bare webm |
| Canvas 2D (`drawImage` + `toBlob`) | 320 px JPEG evidence snapshots (q0.6) |
| `requestAnimationFrame` | the detection loop (throttled internally to 300/1500 ms) |
| Fullscreen API, `visibilitychange`, clipboard/contextmenu events | the non-AI anti-cheat layer in the attempt player |
| `fetch` (multipart `FormData`) | direct browser→S3 presigned POST of clips |

## Frontend stack (already in the app)

- **Next.js / React 18 + TypeScript** — `WebcamProctor` component, hooks-based wiring; the detector and recorder are deliberately framework-agnostic classes so they're portable.
- **axios** (shared `api.ts` client) — the six proctoring calls; snapshot upload explicitly sets multipart Content-Type (a missing header once caused snapshot 422s — see history note below).
- **lucide-react** — icons; **Tailwind** — styling (consent modal, self-view pill, report).

## Backend stack (already in the app)

- **FastAPI + Pydantic** — the six endpoints; `ProctoringEventRequest` schema validates event types.
- **SQLAlchemy + Alembic** — single JSON column `ap_attempts.proctoring` (migration `f3a7c9e1d5b8`); list endpoints `defer()` the heavy JSON blobs.
- **boto3** — `generate_presigned_post` (clip upload policy: webm-only, ≤ 10 MB, 120 s) and `head_object` (commit verification); `StorageService` handles snapshot storage + presigned GETs for the reviewer report.
- **slowapi** — per-endpoint rate limits (presign 6/min, commit 12/min, media-error 30/min).
- **Amazon S3** (prod bucket `ethara-hrms-doc`) — private evidence storage; bucket CORS must allow browser POST + GET from the app origin.

## History note for the team (why the code looks the way it does)

Two early bugs shaped the current design — don't reintroduce them:
1. **Snapshot 422s** — the axios client's default JSON Content-Type broke the multipart snapshot upload; the fix pins the multipart header explicitly in `api.ts`.
2. **Garbled clips** — the first recorder kept a rolling ring buffer and spliced chunks on violation; webm chunks after the first lack container headers, so spliced files were corrupt. The rewrite records **one fresh continuous MediaRecorder session per clip**, which is always a valid file. That's also why `captureClip()` refuses to start while busy instead of queueing.
